from django.contrib import admin
from my_awesome_api.models import Account,Destination

admin.site.register(Account)
admin.site.register(Destination)
# Register your models here.
